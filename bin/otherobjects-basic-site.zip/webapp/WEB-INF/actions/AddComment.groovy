import org.otherobjects.cms.model.*;

// FIXME Support Ajax processing
// 1. get object (shoud be able to be anything!) out of request data
// 2. validate
// 3.   return errors via json or via session.redirect
// 4. process object
// 5.   return errors via json or via session.redirect
// 6. redirect to success view

// Bind and Validate
def result = action.bindAndValidate("org.otherobjects.cms.model.Comment")

// Return to form on error
if(result.hasErrors()) {
	action.error("Could not add your comment due to form errors. See form below for details.", result);
	return;
}

// Create folder if it doesn't already exis
def f = jcr.getByPath("/libraries/comments/")
if(!f)
{
	action.flashInfo("Creating comment folder");
	f = new SiteFolder()
	f.setPath("/libraries/")
	f.code = "comments" 
	f.label = "Comments"
	f = jcr.save(f);
}
if(!f.published)
{
	action.flashInfo("Publishing comment folder");
	jcr.publish(f, null);
}

// Save Comment
def comment = result.target;
comment.path = "/libraries/comments/"
comment.username = ""+ new Date().getTime()
comment = jcr.save(comment);
//jcr.publish(comment,null);

// Redirect
action.success("Your comment has been added: ${comment.comment}")















// ---------------------------------------
// Stuff actions need to be able to act on 
// ---------------------------------------

// request
// response
// parameters
// session
// cookies 
// forms
// user
// security checks
// logging
// error handling
// background tasks	